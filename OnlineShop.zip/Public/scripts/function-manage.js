// JavaScript Document
function Delete()
{
	if(confirm("确定要删除吗？")) {
		//location.href="../Manage/Home/User/deleteUser/user_id/{$user['user_id']}"
		return true;
	}
	else
		return false;
}