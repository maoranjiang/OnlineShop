<?php
return array(
	//'配置项'=>'配置值'
    'URL_CASE_INSENSITIVE' =>true,
    'DB_TYPE' => 'mysql',
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'onlineshop',
    'DB_USER' => 'root',
    'DB_PWD' => '',
    'DB_PORT' =>3306,
    'DB_PREFIX' =>'think_',
    'DB_CHARSET'=>'utf-8',
    'VAR_URL_PARAMS' => '_URL_',
);